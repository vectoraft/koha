This module also contains copies of
* LibTomCrypt (https://github.com/libtom/libtomcrypt)
* LibTomMath  (https://github.com/libtom/libtommath)
all of which fall into public-domain usage licenses.

Please keep in mind that by contributing any code to
subdirectories src/ltc or src/ltm your contribution
will be considered under the same license as used by
the above-mentioned libraries (public-domain).
