#include "tommath_private.h"
#ifdef S_MP_WARRAY_C
/* LibTomMath, multiple-precision integer library -- Tom St Denis */
/* SPDX-License-Identifier: Unlicense */

mp_thread st_warray s_mp_warray = { 0 };

#endif
