package curry::weak;

use curry;

1;
