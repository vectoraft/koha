#ifndef UU_GETTIME_H
#define UU_GETTIME_H

#include "ulib/UUID.h"

U64 gt_100ns64(pUCXT);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
