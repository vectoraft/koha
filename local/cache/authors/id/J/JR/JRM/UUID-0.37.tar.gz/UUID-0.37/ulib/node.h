#ifndef UU_NODE_H
#define UU_NODE_H

#include "ulib/UUID.h"

int uu_get_node_id(pUCXT, U8 *node_id);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
