#ifndef UU_CLEAR_H
#define UU_CLEAR_H

#include "ulib/UUID.h"

void uu_clear(struct_uu_t *io);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
