#ifndef UU_PARSE_H
#define UU_PARSE_H

#include "ulib/UUID.h"

IV uu_parse(const char *in, struct_uu_t *out);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
