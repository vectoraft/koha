#ifndef UU_ISNULL_H
#define UU_ISNULL_H

#include "ulib/UUID.h"

IV uu_isnull_binary(const uu_t in);
IV uu_isnull_struct(const struct_uu_t *in);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
