#ifndef UU_MD5_H
#define UU_MD5_H

#include "ulib/UUID.h"

void uu_md5_hash(pUCXT, struct_uu_t *out, char *name);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
