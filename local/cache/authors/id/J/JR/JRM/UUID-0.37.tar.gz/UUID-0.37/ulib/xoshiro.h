#ifndef UU_XOSHIRO_H
#define UU_XOSHIRO_H

#include "ulib/UUID.h"

void xo_srand(pUCXT, Pid_t pid);
U64  xo_rand(pUCXT);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
