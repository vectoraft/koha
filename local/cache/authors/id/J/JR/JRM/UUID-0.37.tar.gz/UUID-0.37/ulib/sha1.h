#ifndef UU_SHA1_H
#define UU_SHA1_H

#include "ulib/UUID.h"

void uu_sha_hash(pUCXT, struct_uu_t *out, char *name);

#endif
/* ex:set ts=2 sw=2 itab=spaces: */
