package MyMooseObject;

use strict;
use warnings;
use parent 'Moose::Object';

1;
