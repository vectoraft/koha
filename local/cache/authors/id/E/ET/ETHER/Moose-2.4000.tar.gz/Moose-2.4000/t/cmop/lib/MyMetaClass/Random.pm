package MyMetaClass::Random;

use strict;
use warnings;

1;
