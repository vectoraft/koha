[String-Random](https://metacpan.org/release/String-Random) on CPAN.
