/*
 * foo/bar/baz.js development asset
 */
