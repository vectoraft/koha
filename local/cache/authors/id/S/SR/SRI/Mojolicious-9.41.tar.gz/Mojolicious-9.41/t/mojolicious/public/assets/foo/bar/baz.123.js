/*
 * foo/bar/baz.js asset
 */
