package DBIx::Class::TestComponent;
use strict;
use warnings;

sub dbix_class_testcomponent { 'dbix_class_testcomponent works' }

1;
